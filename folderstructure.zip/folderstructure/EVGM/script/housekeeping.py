import os,sys,io,time,datetime,subprocess,configparser,logging,logging.handlers,shutil
from string import Template

def load_config(config_file):
  config = configparser.ConfigParser()
  config.read(sys.argv[1])
  global workdir,logdir,archdir,dirage,debug

  if 'WORKDIR' in config['MAIN']:
    workdir=config['MAIN']['WORKDIR']
    if not os.path.isdir(workdir): sys.exit(workdir+" not found\n")
  else: sys.exit("WORKDIR is not defined\n")

  if 'LOGDIR' in config['MAIN']:
    logdir=config['MAIN']['LOGDIR']
    if not os.path.isdir(logdir): sys.exit(logdir+" not found\n")
  else: sys.exit("LOGDIR is not defined\n")

  if 'ARCHDIR' in config['MAIN']:
    archdir=config['MAIN']['ARCHDIR']
    if not os.path.isdir(archdir): sys.exit(archdir+" not found\n")
  else: sys.exit("ARCHDIR is not defined\n")

  if 'DIRAGE' in config['MAIN']: dirage=config['MAIN']['DIRAGE']
  else: sys.exit("DIRAGE is not defined\n")

  if 'DEBUG' in config['MAIN']: debug=config['MAIN']['DEBUG']
  else: sys.exit("DEBUG is not defined\n")

### main
workdir=''
logdir=''
archdir=''
dirage=''
debug=''

# Check syntax
if len(sys.argv) < 2: sys.exit ('Syntax should be : <script> <ini file>')

# Check ini file
if not os.path.isfile(sys.argv[1]): sys.exit (sys.argv[1]+' not found\n')

taskname=os.path.splitext(os.path.basename(sys.argv[1]))[0]

# Set error folder
config = configparser.ConfigParser()
config.read(sys.argv[1])
if 'ERRDIR' in config['MAIN']:
  errdir=config['MAIN']['ERRDIR']
  if not os.path.isdir(errdir): sys.exit(errdir+" not found\n")
else: sys.exit("ERRDIR is not defined")

errfile=errdir+'\\'+taskname+'.err'

try:
  load_config(sys.argv[1])
except SystemExit as e:
  ef = io.open(errfile, 'a')
  ef.write(str(e))
  ef.close()
  os._exit(1)

logfile=logdir+'\\'+taskname+'.log'
# Set up a logger
logger = logging.getLogger(taskname)
logger.setLevel(logging.DEBUG)
# Set log rotation
handler = logging.handlers.RotatingFileHandler(logfile, maxBytes=5*1024*1024, backupCount=5)
df = logging.Formatter('$asctime $name ${levelname} $message',style='$')
handler.setFormatter(df)
logger.addHandler(handler)

logger.info('Begin')

now = time.time()
### Purge archive folders ###
# Get message type subfolders
for entry in os.scandir(archdir):
  if (debug == '1'): logger.debug('Checking : '+entry.name)
  if not entry.name.startswith('.') and entry.is_dir():
    # Get YYYYMMDD subfolders
    for subfolder in os.scandir(entry.path):
      if not subfolder.name.startswith('.') and subfolder.is_dir():
        # More than {dirage} days old
        if (debug == '1'): logger.debug('Check Age : '+subfolder.name)
        if subfolder.stat().st_mtime < now - int(dirage)*86400:
          logger.info('Delete : '+entry.name+'\\'+subfolder.name)
          shutil.rmtree(subfolder.path, ignore_errors=True)

logger.info('End')
