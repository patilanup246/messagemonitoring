import os,sys,io,time,datetime,subprocess,configparser,logging,logging.handlers,shutil
from string import Template

def load_config(config_file):
  config = configparser.ConfigParser()
  config.read(sys.argv[1])
  global srcpath,destpath,workdir,logdir,archdir,fileage,cdcli,debug,batchsize,cdauth,cdjob

  if 'SRCDIR' in config['MAIN']:
    srcpath=config['MAIN']['SRCDIR']
    if not os.path.isdir(srcpath): sys.exit(srcpath+" not found\n")
  else: sys.exit("SRCDIR is not defined\n")

  if 'DESTDIR' in config['MAIN']: destpath=config['MAIN']['DESTDIR']
  else: sys.exit("DESTDIR is not defined\n")

  if 'WORKDIR' in config['MAIN']:
    workdir=config['MAIN']['WORKDIR']
    if not os.path.isdir(workdir): sys.exit(workdir+" not found\n")
  else: sys.exit("WORKDIR is not defined\n")

  if 'LOGDIR' in config['MAIN']:
    logdir=config['MAIN']['LOGDIR']
    if not os.path.isdir(logdir): sys.exit(logdir+" not found\n")
  else: sys.exit("LOGDIR is not defined\n")

  if 'APERAK' in srcpath:
    if 'ARCHDIR' in config['MAIN']:
      archdir=config['MAIN']['ARCHDIR']
      if not os.path.isdir(archdir): sys.exit(archdir+" not found\n")
      else: 
        today = datetime.datetime.today().strftime('%Y%m%d')
        archdir=archdir+'\\'+today
        if not os.path.exists(archdir): os.makedirs(archdir)
    else: sys.exit("ARCHDIR is not defined\n")

  if 'CDCLI' in config['MAIN']: cdcli=config['MAIN']['CDCLI']
  else: sys.exit("CDCLI is not defined\n")

  if 'FILEAGE' in config['MAIN']: fileage=config['MAIN']['FILEAGE']
  else: sys.exit("FILEAGE is not defined\n")

  if 'DEBUG' in config['MAIN']: debug=config['MAIN']['DEBUG']
  else: sys.exit("DEBUG is not defined\n")

  if 'BATCHSIZE' in config['MAIN']: batchsize=config['MAIN']['BATCHSIZE']
  else: sys.exit("BATCHSIZE is not defined\n")

  if 'CDAUTH' in config['CD']:
    cdauth=config['CD']['CDAUTH']
    if not os.path.isfile(cdauth): sys.exit(cdauth+" not found\n")
  else: sys.exit("CDAUTH is not defined\n")

  if 'CDJOB' in config['CD']:
    cdjob=config['CD']['CDJOB']
    if not os.path.isfile(cdjob): sys.exit(cdjob+" not found\n")
  else: sys.exit("CDJOB is not defined\n")

def addto_cdjob(obfile):
  global srcpath,destpath,workdir,errdir,archdir,debug,cdjob,cfgfile
  logger.info('Processing : '+obfile)

  # archive ob file
  shutil.copy2(srcpath+'\\'+obfile,archdir+'\\'+obfile)

  # rename ob file
  srcfileprc=obfile+'.prc'
  os.rename(srcpath+'\\'+obfile,srcpath+'\\'+srcfileprc)

  # add file to CD job
  cdcmd = io.open(cfgfile, 'a')
  d = dict(cdp=cdjob,srcdir=srcpath,srcfile=srcfileprc,destdir=destpath,destfile=obfile)
  cdcmd.write(Template('submit file=$cdp &SRCDIR=$srcdir &SRCFILE=$srcfile &DESTDIR=$destdir &DESTFILE=$destfile;\n').safe_substitute(d))
  cdcmd.close()
  if (debug == '1'):
    f = io.open(cfgfile, 'r')
    logger.debug('CD submit : '+f.read())
    f.close()

def submit_cdjob():
  global cdauth,cfgfile,cdcli,errfile
  logger.info('Submit job : '+cfgfile)

  # submit job to CD
  d = dict(cli=cdcli,cda=cdauth,cmdfile=cfgfile)
  cmd = Template('$cli -f$cda < $cmdfile').safe_substitute(d)
  if (debug == '1'): logger.debug('CD call : '+cmd)
  try:
    output = subprocess.check_output(cmd,stderr=subprocess.STDOUT,shell=True)
  except subprocess.CalledProcessError as cmdexc:
    logger.error('Failed to call CD CLI : '+str(cmdexc.returncode)+' OUTPUT: '+str(cmdexc.output))
    ef = io.open(errfile, 'a')
    ef.write('Failed to call CD CLI : '+str(cmdexc.returncode)+' OUTPUT: '+str(cmdexc.output))
    ef.close()
  if (debug == '1'): logger.debug('CD command output : '+str(output))

  # delete the CD command file
  os.remove(cfgfile)

### main
srcpath=''
destpath=''
workdir=''
logdir=''
archdir=''
cdcli=''
fileage=''
debug=''
batchsize=''
cdauth=''
cdjob=''

# Check syntax
if len(sys.argv) < 2: sys.exit ('Syntax should be : <script> <ini file>')

# Check ini file
if not os.path.isfile(sys.argv[1]): sys.exit (sys.argv[1]+' not found\n')

taskname=os.path.splitext(os.path.basename(sys.argv[1]))[0]

# Set error folder
config = configparser.ConfigParser()
config.read(sys.argv[1])
if 'ERRDIR' in config['MAIN']:
  errdir=config['MAIN']['ERRDIR']
  if not os.path.isdir(errdir): sys.exit(errdir+" not found\n")
else: sys.exit("ERRDIR is not defined")

errfile=errdir+'\\'+taskname+'.err'

try:
  load_config(sys.argv[1])
except SystemExit as e:
  ef = io.open(errfile, 'a')
  ef.write(str(e))
  ef.close()
  os._exit(1)

logfile=logdir+'\\'+taskname+'.log'
# Set up a logger
logger = logging.getLogger(taskname)
logger.setLevel(logging.DEBUG)
# Set log rotation
handler = logging.handlers.RotatingFileHandler(logfile, maxBytes=5*1024*1024, backupCount=5)
df = logging.Formatter('$asctime $name ${levelname} $message',style='$')
handler.setFormatter(df)
logger.addHandler(handler)

logger.info('Begin')

now = time.time()
obfiles = dict ([(f, None) for f in os.scandir (srcpath)])
bc=1
cfgfile=workdir+'\\'+taskname+'_'+str(now)+'_'+str(bc)+'.cmd'
fc=0
for obf in obfiles:
  if (debug == '1'): logger.debug('Checking : '+obf.name)
  if not obf.name.startswith('.') and not obf.name.endswith('.prc') and obf.is_file():
    # More than {fileage} seconds old
    if (debug == '1'): logger.debug('Check Age ('+str(now-int(fileage))+') '+str(obf.stat().st_mtime))
    if obf.stat().st_mtime < now - int(fileage):
      addto_cdjob(obf.name)
      fc=fc+1
      if (fc%int(batchsize)) == 0:
        cdcmd = io.open(cfgfile, 'a')
        cdcmd.write('quit;\n')
        cdcmd.close()
        submit_cdjob()
        bc=bc+1
        cfgfile=workdir+'\\'+taskname+'_'+str(now)+'_'+str(bc)+'.cmd'

### For the last CD cmd file
if os.path.isfile(cfgfile):
  cdcmd = io.open(cfgfile, 'a')
  cdcmd.write('quit;\n')
  cdcmd.close()
  submit_cdjob()

logger.info('Total number of files sent : '+str(fc))
logger.info('End')
